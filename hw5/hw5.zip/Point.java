public class Point {
	
	private int x;
	private int y;
	
	public Point() {
		x = 1;
		y = 1;
	}
	
	public Point(int a) {
		x = a;
		y = a;
	}
	
	public Point(int a, int b) {
		x = a;
		y = b;
	}
	
//	getter method
	public int getX(){
		return x;
	}
	
	public int getY() {
		return y;
	}
	
//	setter method
	public void setX(int a) {
		x = a;
	}
	
	public void setY(int b) {
		y = b;
	}
	
//	toString method
	public String toString() {
		return ("(x,y) = ("+ x +","+ y +")");
		
	}
}
