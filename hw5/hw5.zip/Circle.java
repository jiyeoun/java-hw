public class Circle extends Shape{
	
	private float radius;
	
	public Circle() {
		this(new Point(10,10), 300);
	}
	
	public Circle(float r) {
		this(new Point(20,20), r);
	}
	
	public Circle(Point pos, float r) {
		super(pos);
		this.radius = r;
	}
	
//	getter method
	public float getRadius() {
		return radius;
	}
	
//	setter method
	public void setRadius(float a) {
		this.radius = a;
	}
	
//	overloading
	public void set() {
		setRadius(0);
	}
	
	public void set(float r) {
		setRadius(r);
	}
	
	public void set(Point c) {
		setPosition(c);
	}
	
	public void set(Point c,float r) {
		setPosition(c);
		setRadius(r);
	}
	
//	toString method
	public String toString() {
		return(super.toString() + "Circle object with the radius of" + this.radius);
	}
	
//	getArea method
	public double getArea() {
		return (this.radius*this.radius*Math.PI);
	}
	
//	increaseRadius method
	public void increaseRadius(int d) {
		setRadius(this.radius + d);
	}
}