package hw7;

public interface InterfaceProfit {
	public double getProfit();
}