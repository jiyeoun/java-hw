package hw7;

import java.io.*;
import java.util.Calendar;
import java.util.Scanner;
import java.io.*;

public class ShoppingCenter2 {
public static void main(String[] args) throws IOException {
		
		final int LIMIT_INVENTORY_NUMBER = 5;
		final int LIMIT_PRODUCT_NUMBER = 3;
		final int LIMIT_CUSTOMER_NUMBER = 2;
		String target = "C:/Users/Jiyeoun Kim/eclipse-workspace/java-study/product.txt";
		String endtarget = "C:/Users/Jiyeoun Kim/Desktop/out.txt";
		int ItemSplit = 5;
		
		FileOutputStream output = new FileOutputStream(endtarget);
		
		/* ���μ��ʹ� ��ü���� product list�� �����Ѵ�*/
		Product[] shopProductList;
		int shopProductNumber = LIMIT_INVENTORY_NUMBER;
		
		if (args.length > 1) {
			shopProductNumber = Integer.parseInt(args[0]);
		}
		
		shopProductList = new Product[shopProductNumber];
		
	    try {
	        BufferedReader in = new BufferedReader(new FileReader(target));
	        String s;
	        int cnt = 0;
	        while ((s = in.readLine()) != null) {
	        	String[] words = s.split(", ");
        		for (int i = 0; i < ItemSplit; i++) {
        			shopProductList[i] = new Product(words[cnt], Integer.parseInt(words[cnt+1]), Integer.parseInt(words[cnt+2]));	
		        	cnt += 3;
        		}
	        }
	      } catch (IOException e) {
	          System.err.println(e);
	          System.exit(1);
	      }	
		
		// �մ����� ���� ���
		InterfaceProfit[] customerList = new InterfaceProfit[LIMIT_CUSTOMER_NUMBER];
		
		/* Ordering ���� �ޱ�*/
		
		int cnum = 0;
		
		int[] customerBuyList = new int[LIMIT_PRODUCT_NUMBER];
		String[][] customerBuyname = new String[2][LIMIT_PRODUCT_NUMBER];
		
		Scanner input = new Scanner(System.in);
		
		int choice;
		int[] numList = {0, 0, 0, 0, 0};

		for (int b=0; b<customerBuyList.length; b++) {
			for (int i=0; i< shopProductList.length; i++) {
				System.out.println(i + " : " + shopProductList[i].getPName());
			}
			System.out.println("������� ������ ��ȣ�� �Է��ϼ���");
			
			choice = input.nextInt();
			if (choice == 0) {
				numList[0] += 1;
			} else if (choice == 1) {
				numList[1] += 1;
			} else if (choice == 2) {
				numList[2] += 1;
			} else if (choice == 3) {
				numList[3] += 1;
			} else if (choice == 4) {
				numList[4] += 1;
			}
			customerBuyList[b] = shopProductList[choice].getPPrice();
			customerBuyname[0][b] = shopProductList[choice].getPName();
		}
		
		
		// Order ������
		Calendar today = Calendar.getInstance();
		//Order customer1 = new Order("ȫ�浿", today, customerBuyList);

		customerList[0] = new Order("������", today, customerBuyList);
		
		System.out.println("�ֹ��� ���� : " + customerList[0].toString());
		String data = "�ֹ��� ���� : " + customerList[0].toString() + " \r\n";
		output.write(data.getBytes());

		
		int cnum1 = 1;
		
		for (int b=0; b<customerBuyList.length; b++) {
			for (int i=0; i< shopProductList.length; i++) {
				System.out.println(i + " : " + shopProductList[i].getPName());
			}
			System.out.println("������� ������ ��ȣ�� �Է��ϼ���");
			
			choice = input.nextInt();
			if (choice == 0) {
				numList[0] += 1;
			} else if (choice == 1) {
				numList[1] += 1;
			} else if (choice == 2) {
				numList[2] += 1;
			} else if (choice == 3) {
				numList[3] += 1;
			} else if (choice == 4) {
				numList[4] += 1;
			}
			customerBuyList[b] = shopProductList[choice].getPPrice();
			customerBuyname[1][b] = shopProductList[choice].getPName();
		}
		
		
		// Order ������
		Calendar today1 = Calendar.getInstance();

		customerList[1] = new Order("������", today1, customerBuyList);
		System.out.println("�ֹ��� ���� : " + customerList[1].toString());
		data = "�ֹ��� ���� : " + customerList[1].toString() + " \r\n";
		output.write(data.getBytes());
	
		
		
		// ������ ����ϱ�
		
		double sum = 0.0;
		for( int c=0; c<customerList.length; c++) {
			sum += customerList[c].getProfit();
		}
		
		// �� �ǸŹ�ǰ ����
		for (int i: numList) {
			System.out.println(i);
		}
		
		// ���� ���
		System.out.println("----------------ó�� ����� ����մϴ�.---------------");
		
		for (int i=0; i<5; i++) {
			data = shopProductList[i].getPName() + "�� �� �ֹ� ���� : " + numList[i] + "�� \r\n";
			output.write(data.getBytes());
		}
		data = "���� �Ѿ� : " + sum;
		output.write(data.getBytes());
		output.close();
	}//main
}
