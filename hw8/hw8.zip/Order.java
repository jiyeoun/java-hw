package hw7;

import java.util.Calendar;
import java.util.Arrays;

public class Order implements InterfaceProfit  {

	private String cName;
	private Calendar today;
	private int[] productList;
	
	//�迭 element�� ���������� ���ϱ�
	//private Product[] productList;
	private int tranID;
	static int currentTransactionNumber = 1;
	
	//Constructors
	
	public Order() {
		cName = "Someone";
		today = Calendar.getInstance();
		productList = null;
		tranID = currentTransactionNumber;
		currentTransactionNumber++;
	}
	
	public Order(String cName, Calendar today, int[] customerBuyList) {
		this.cName = cName;
		this.today = today;
		this.productList = customerBuyList;
		this.tranID = currentTransactionNumber;
		currentTransactionNumber++;
	}
	
	
	//getter setter
	
	public String getcName() {
		return cName;
	}
	
	public void setcName(String cName) {
		this.cName = cName;
	}
	
	public Calendar getToday() {
		return today;
	}
	
	public void setToday(Calendar today) {
		this.today = today;
	}
	
	public int[] getProdectList() {
		return productList;
	}
	
	public void setProductList(int[] productList) {
		this.productList = productList;
	}
	
	public void setProductNumber(int[] pNumber) {
		this.productList = pNumber;
	}
	
	public int getTranID() {
		return tranID;
	}
	
	public void setTranID(int tranID) {
		this.tranID = tranID;
	}
	
	@Override
	public String toString() {
		int month = today.get(Calendar.MONTH) + 1;
		int day = today.get(Calendar.DAY_OF_MONTH);
		return (month + "/" + day + " : " + cName + "/ �ֹ���ȣ : " + getTranID());
	}

	@Override
	public double getProfit() {
		double sum = 0.0;
		for (int i=0; i< productList.length; i++) {
			sum += productList[i];
		}
		return sum;
		}
	}


