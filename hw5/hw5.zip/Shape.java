public class Shape {
	
	private Point position;
	public Shape() {
		position = new Point(5,5);
	}
	
	public Shape(Point pos) {
		this.position = pos;
	}
	
	/*setter & getter methods */
	
	public Point getPosition() {
		return position;
	}
	
	public void setPosition(Point position) {
		this.position = position;
	}
	
	/* getArea() */
	
	public double getArea() {
		return 0.0;
	}
	
	/* toString() */
	
	public String toString() {
		return("Shape class at position (x,y)=(" + position.getX() + ", " + position.getY() + ")");
	}
}
