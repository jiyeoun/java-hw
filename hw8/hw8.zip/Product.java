package hw7;

public class Product {
	
	private String PName;
	private int PPrice;
	private int UPC;
	
	//constructors
	
	public Product() {
		PName = "None";
		PPrice = 0;
		UPC = 0;
	}
	
	public Product(String PName, int PPrice, int UPC) {
		this.PName = PName;
		this.PPrice = PPrice;
		this.UPC = UPC;
	}
	
	//getter setter
	public String getPName() {
		return PName;
	}
	
	public void setPName(String pName) {
		PName = pName;
	}
	
	public int getPPrice() {
		return PPrice;
	}
	
	public void setPPrice(int pPrice) {
		PPrice = pPrice;
	}
	
	public int getUPC() {
		return UPC;
	}
	
	public void setUPC(int pUPC) {
		UPC = pUPC;
	}

	@Override
	public String toString() {
		return "[name=" + PName + ", price=" + PPrice + ", productNumber=" + UPC + "]";
	}
	
}
