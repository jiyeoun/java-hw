public class Rectangle extends Shape {

	private float height;
	private float width;
	
	public Rectangle(){
		this(new Point(5,10), 5, 10);
	}
	
	public Rectangle(float h){
		this(new Point(15,20), h, 10);
	}
	
	public Rectangle(float h, float w) {
		this(new Point(25,30), h, w);
	}
	
	public Rectangle(Point pos, float h, float w) {
		super(pos);
		this.height = h;
		this.width = w;
	}
	
//	getter method
	public float getHeight() {
		return height;
	}
	
	public float getWidth() {
		return width;
	}
	
//	setter method
	public void setHeight(float h) {
		this.height = h;
	}
	
	public void setWidth(float w) {
		this.width = w;
	}
	
//	overloading
	public void set() {
		setHeight(0);
		setWidth(0);
	}
	
	public void set(float h) {
		setHeight(h);
	}
	
	public void set(float h, float w) {
		setHeight(h);
		setWidth(w);
	}
	
	public void set(Point c) {
		setPosition(c);
	}
	
	public void set(Point c, float h, float w) {
		setPosition(c);
		setHeight(h);
		setWidth(w);
	}
	
	
//	toString method
	public String toString() {
		return("Rectahgle Position = "+ super.toString() + " height = "+ this.height + " width = "+ this.width);
	}
	
//	getArea method
	public double getArea() {
		return this.width*this.height;
	}
	
//	changeShapes method
	public void changeShapes() {
		float copyHeight = this.height;
		float copyWidth = this.width;
		this.height = copyWidth;
		this.width = copyHeight;
	}
}