package hw6;

public interface InterfaceProfit {
	public double getProfit();
}