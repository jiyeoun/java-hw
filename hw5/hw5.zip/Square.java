public class Square extends Shape {

	private float side;
	
	public Square() {
		this(new Point(10,10), 5);
	}
	
	public Square(float a) {
		this(new Point(20,20), a);
	}
	
	public Square(Point pos, float a) {
		super(pos);
		this.side = a;
	}
	
//	getter method
	public float getSquare(){
		return side;
	}
	
//	setter method
	public void setSquare(float a) {
		this.side = a;
	}
	
// overloading
	public void set() {
		setSquare(0);
	}
	
	public void set(float a) {
		setSquare(a);
	}
	
	public void set(Point c) {
		setPosition(c);
	}
	
	public void set(Point c, float a) {
		setPosition(c);
		setSquare(a);
	}
	
	
//	toString method
	public String toString() {
		return("Square Position = "+ super.toString() + " facet = " + this.side);
	}
	
//	getArea method
	public double getArea() {
		return (this.side*this.side);
	}
	
//	increaseSide method
	public void increaseSide(int d) {
		setSquare(this.side + d);
	}
}
