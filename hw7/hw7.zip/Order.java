package hw6;

import java.util.Calendar;
import java.util.Arrays;

public class Order implements InterfaceProfit  {

	private String cName;
	private Calendar today;
	private int realday;
	private int[] productList;
	
	//�迭 element�� ���������� ���ϱ�
	//private Product[] productList;
	private int tranID;
	
	static int currentTransactionNumber = 0;
	
	//Constructors
	
	public Order(String string, int date, Product[] abuy) {
		cName = "Someone";
		today = Calendar.getInstance();
		realday = Calendar.DAY_OF_MONTH;
		productList = null;
		tranID = currentTransactionNumber;
		currentTransactionNumber++;
	}
	
	public Order(String cName, Calendar today, int[] productList, int tranID) {
		this.cName = cName;
		this.today = today;
		this.productList = productList;
		this.tranID = tranID;
	}
	
	//getter setter
	
	public String getcName() {
		return cName;
	}
	
	public void setcName(String cName) {
		this.cName = cName;
	}
	
	public Calendar getToday() {
		return today;
	}
	
	public void setToday(Calendar today) {
		this.today = today;
	}
	
	public int[] getProdectList() {
		return productList;
	}
	
	public void setProductList(int[] productList) {
		this.productList = productList;
	}
	
	public void setProductNumber(int pNumber) {
		this.productList = new int[pNumber];
	}
	
	public int getTranID() {
		return tranID;
	}
	
	public void setTranID(int tranID) {
		this.tranID = tranID;
	}
	
	@Override
	public String toString() {
		return "[today=" + this.realday + ", tranID=" + this.tranID + ", name=" + this.cName + ", products=" + Arrays.toString(productList) + "]";
	}

	@Override
	public double getProfit() {
		int sumPrice = 0;
		for(Product i : productList) { 
			sumPrice += i.getPPrice(); }
		return sumPrice;
	}



}
