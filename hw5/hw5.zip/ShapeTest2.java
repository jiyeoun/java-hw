
public class ShapeTest2 {

	   public static void main(String[] args) {
		
		Point pt1 = new Point();
		Point pt2 = new Point(10, 10);
		Point pt3 = new Point(20);
		
		Shape[] myShapeList = new Shape[12];
	
		//�迭�� element object ����	
		myShapeList[0] = new Shape();
		myShapeList[1] = new Shape(pt2);
		myShapeList[2] = new Shape(pt3);
		myShapeList[3] = new Circle();
		myShapeList[4] = new Circle(200);
		myShapeList[5] = new Circle(pt2, 100);
		myShapeList[6] = new Rectangle();
		myShapeList[7] = new Rectangle(10);
		myShapeList[8] = new Rectangle(15,15);
		myShapeList[9] = new Square();
		myShapeList[10] = new Square(10);
		myShapeList[11] = new Square(pt2, 15);
		
		System.out.println("---------------������ Ȯ��---------------");
		
		//������ Ȯ��
		for (int i=0; i<myShapeList.length; i++) {
			System.out.println(myShapeList[i].toString());
			System.out.println("������" + myShapeList[i].getArea());
		}
		
		System.out.println("---------------getter setter �� ����---------------");
		
		//getter�� setter�� �� ����
		//Shape setter getter objects
		myShapeList[0].setPosition(pt1);
		Point position = myShapeList[0].getPosition();
		System.out.println("After fix Shape position" + myShapeList[0]);
		
		myShapeList[1].setPosition(pt3);
		Point position1 = myShapeList[1].getPosition();
		System.out.println("After fix Shape position" + myShapeList[1]);
		
		myShapeList[2].setPosition(pt2);
		Point position2 = myShapeList[2].getPosition();
		System.out.println("After fix Shape position" + myShapeList[2]);
		
		
		//Circle setter getter objects
		((Circle) myShapeList[3]).setRadius(30);
		float radius1 = ((Circle) myShapeList[3]).getRadius();
		System.out.println("After fix Circle1 Radius " + ((Circle) myShapeList[3]));
		
		((Circle) myShapeList[4]).setRadius(40);
		float radius2 = ((Circle) myShapeList[4]).getRadius();
		System.out.println("After fix Circle2 Radius " + ((Circle) myShapeList[4]));
		
		((Circle) myShapeList[5]).setRadius(50);
		float radius3 = ((Circle) myShapeList[5]).getRadius();
		System.out.println("After fix Circle3 Radius " + ((Circle) myShapeList[5]));
		
		//Rectangle setter getter objects
		((Rectangle) myShapeList[6]).setHeight(55);
		float height1 = ((Rectangle) myShapeList[6]).getHeight();
		((Rectangle) myShapeList[6]).setWidth(55);
		float width1 = ((Rectangle) myShapeList[6]).getWidth();
		System.out.println("After fix Rectangle1 height and width = " + ((Rectangle) myShapeList[6]));
		
		((Rectangle) myShapeList[7]).setHeight(66);
		float height2 = ((Rectangle) myShapeList[7]).getHeight();
		((Rectangle) myShapeList[7]).setWidth(66);
		float width2 = ((Rectangle) myShapeList[7]).getWidth();
		System.out.println("After fix Rectangle2 height and width = " + ((Rectangle) myShapeList[7]));
		
		((Rectangle) myShapeList[8]).setHeight(77);
		float height3 = ((Rectangle) myShapeList[8]).getHeight();
		((Rectangle) myShapeList[8]).setWidth(77);
		float width3 = ((Rectangle) myShapeList[8]).getWidth();
		System.out.println("After fix Rectangle3 height and width = " + ((Rectangle) myShapeList[8]));

		//Square setter getter objects
		((Square) myShapeList[9]).setSquare(30);
		float facet1 = ((Square) myShapeList[9]).getSquare();
		System.out.println("After fix Square1 facet " + ((Square) myShapeList[9]));
		
		((Square) myShapeList[10]).setSquare(40);
		float facet2 = ((Square) myShapeList[10]).getSquare();
		System.out.println("After fix Square2 facet " + ((Square) myShapeList[10]));
		
		((Square) myShapeList[11]).setSquare(50);
		float facet3 = ((Square) myShapeList[11]).getSquare();
		System.out.println("After fix Square3 facet " + ((Square) myShapeList[11]));
		
		
		//subclass�� Ư�� �޼��� ���
		for (int i=0; i<myShapeList.length; i++) {
			if(myShapeList[i] instanceof Circle) {
				Circle c = (Circle) myShapeList[i];
				c.increaseRadius(5);
			}
			else if(myShapeList[i] instanceof Square) {
				Square s = (Square) myShapeList[i];
				s.increaseSide(5);
			}
			else if(myShapeList[i] instanceof Rectangle) {
				Rectangle r = (Rectangle) myShapeList[i];
				r.changeShapes();
			}
		}
	}
}